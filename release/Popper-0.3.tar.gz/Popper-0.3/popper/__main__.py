# -*- coding: utf-8 -*-

"""bootstrap.__main__: executed when bootstrap directory is called as script."""

from .popper import main
main()
